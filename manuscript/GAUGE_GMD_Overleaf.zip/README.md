# GAUGE GMD manuscript package

This directory contains the complete one-column submission draft prepared with
the official Copernicus Publications LaTeX package, version 7.14 (12 March
2026).

## Overleaf

The easiest route is to upload `../GAUGE_GMD_Overleaf.zip` as a new Overleaf
project. The main document is `manuscript.tex`; use pdfLaTeX. The archive
preserves the `tables/` subdirectory and includes the Copernicus class,
configuration, bibliography style, bibliography, and all figure files.

Some Tectonic-based preview services, including Prism, crash while loading the
FontAwesome support bundled through the official Copernicus class. For those
services, use `../GAUGE_GMD_Prism.zip`. It differs only by replacing the two
unused deceased/equal-contribution author-marker icons with empty definitions.
Use the official-class Overleaf archive for submission.

`manuscript.pdf` is the locally reviewed preview. The repository's official
`copernicus.cls` is unmodified. The preview was compiled in a temporary build
directory with two unused FontAwesome author-marker commands disabled because
the local Tectonic engine crashes while loading that font; this does not affect
Overleaf or the manuscript source.

## Rebuild generated manuscript assets

From the repository root:

```bash
python scripts/render_gmd_survey_figure.py  # literature-review figure
python scripts/build_gmd_tables.py
python scripts/build_gmd_bibliography.py
python scripts/audit_gmd_manuscript.py
python scripts/package_gmd_overleaf.py
```

The TC figures are copied from the checksummed paper bundle under
`case_studies/tropical_cyclone_bt/paper_results/`. The statistical-validation
figure is copied from `validation/statistical_validation_v0.2.pdf`. The survey
source files retain their historical repository name; the literature-review
figure, appendix tables, and bibliography
are generated from their canonical machine-readable sources.

## Appendices and supplements

The technical figures and tables remain appendices in the main manuscript. This
follows the GMD manuscript-composition guidance, which asks authors to place
normal-size figures, tables, and non-essential technical developments in appendices
and reserves a separate supplement for material that cannot reasonably be included
there. A page break before and after the appendices prevents appendix floats from
appearing among the conclusions or author statements. Code and data availability,
author contributions, competing interests, and acknowledgements remain in the main
manuscript after the appendices.

## Submission metadata still requiring author action

These are not scientific-analysis tasks and must not be guessed:

1. Deposit the immutable software release and permission-cleared TC artifacts,
   then replace the provisional availability wording with the resulting DOI(s)
   and add the archive citation(s) to `references.bib`.
2. Confirm all author, affiliation, funding, grant, and contributor metadata.
3. Select a key figure; `fig01.pdf` is the natural graphical-abstract choice.
4. Paste `short_summary.txt` into the GMD submission form.

The manuscript correctly describes the 69-paper evidence base as a structured review
of a curated corpus rather than a probability sample, so none of its counts is
presented as a field-wide prevalence estimate. The canonical review protocol
still marks the search freeze and independent recoding as incomplete. Those
gates must be completed and the generated counts re-audited before submission;
the present manuscript wording must not be used to imply that this work is
already complete.
